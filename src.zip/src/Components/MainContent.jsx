import React from 'react';

const MainContent = () => {
  return (
    <div className="main-content">
      {/* Main content of the website */}
      <h1>Welcome to Our Website</h1>
      <p>This is where you can add your main content.</p>
      {/* Other content goes here */}
    </div>
  );
}

export default MainContent;
