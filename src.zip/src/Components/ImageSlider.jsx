import React, { useState, useEffect } from 'react';
import logo from './img/bild1.jpg';
import logo1 from './img/bild2.jpg';
import logo2 from './img/bild3.jpg';
import './Slideshow.css';

const Slideshow = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const images = [logo, logo1, logo2];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev === images.length - 1 ? 0 : prev + 1));
  };

  // Automatically change the slide every 5 seconds
  useEffect(() => {
    const intervalId = setInterval(nextSlide, 5000);
    
    // Clean up the interval when the component unmounts
    return () => clearInterval(intervalId);
  }, []);

  return (
    <div className="container">
      <img src={images[currentSlide]} alt={`Slide ${currentSlide}`} />
    </div>
  );
};

export default Slideshow;
