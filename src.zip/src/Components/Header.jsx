import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { SidebarData } from './SlidebarData';
import './Header.css';
import Hamburger from 'hamburger-react';
import { FaFacebook, FaInstagram, FaEnvelope, FaPhone } from 'react-icons/fa';

function Navbar() {
  const [sidebar, setSidebar] = useState(false);

  const toggleSidebar = () => {
    setSidebar(!sidebar);
  };

  return (
    <>
      <div className='navbar'>
        <Hamburger toggled={sidebar} toggle={toggleSidebar} color="#fff" />
      </div>
      <nav className={sidebar ? 'nav-menu active' : 'nav-menu'}>
        <div className="menu-scroll">
          <ul className='nav-menu-items'>
            {/* Existing menu items */}
            {SidebarData.map((item, index) => (
              <li key={index} className={item.cName}>
                <Link to={item.path} onClick={toggleSidebar}>
                  {item.icon}
                  <span>{item.title}</span>
                </Link>
              </li>
            ))}

            {/* Social media icons */}
            <li className="nav-text">
              <a href="#" onClick={toggleSidebar}>
                <FaFacebook />
                <span>Facebook</span>
              </a>
            </li>
            <li className="nav-text">
              <a href="#" onClick={toggleSidebar}>
                <FaInstagram />
                <span>Instagram</span>
              </a>
            </li>
            <li className="nav-text">
              <a href="mailto:youremail@example.com" onClick={toggleSidebar}>
                <FaEnvelope />
                <span>Email</span>
              </a>
            </li>
            <li className="nav-text">
              <a href="tel:+1234567890" onClick={toggleSidebar}>
                <FaPhone />
                <span>Telephone</span>
              </a>
            </li>
          </ul>
        </div>
      </nav>
    </>
  );
}

export default Navbar;