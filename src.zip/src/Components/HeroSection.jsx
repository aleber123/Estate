import React from 'react';



function HeroSection() {
    return (
      <div style={{ height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        {/* Hero Section Content */}
      </div>
    );
  }

export default HeroSection;