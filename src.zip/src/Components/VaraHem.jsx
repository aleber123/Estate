import React from 'react';

const VaraHem = () => {
    return <div>Våra Hem Page</div>;
  };

  export default VaraHem;