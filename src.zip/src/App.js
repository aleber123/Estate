import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HeroSection from './Components/HeroSection';
import SocialLinks from './Components/SocialLinks';
import MainContent from './Components/MainContent';
import Footer from './Components/Footer';
import InstagramFeed from './Components/InstagramFeed';
import VaraHem from './Components/VaraHem';
import Slideshow from './Components/ImageSlider'

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/våra-hem" element={<VaraHem />} />
          <Route path="/" element={
            <>
            <Slideshow />
              <HeroSection />
              <InstagramFeed />
              <SocialLinks />
              <MainContent />
            </>
          } />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
